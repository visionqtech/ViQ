import HomeSection from "../components/HomeSection";
import ImageSlider from "../components/ImagesSlider";

export default function Home() {
    return (
        <>
            <ImageSlider />
            <HomeSection />
        </>
    )
}